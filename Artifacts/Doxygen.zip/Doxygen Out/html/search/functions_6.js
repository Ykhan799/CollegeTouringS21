var searchData=
[
  ['souvexists_74',['souvExists',['../class_db_manager.html#ac853b2f31dfb1bc9e96a404ee53566d6',1,'DbManager']]]
];
