var searchData=
[
  ['removesouvenir_73',['removeSouvenir',['../class_db_manager.html#a416f84a355fbc800800448edfac22d42',1,'DbManager']]]
];
