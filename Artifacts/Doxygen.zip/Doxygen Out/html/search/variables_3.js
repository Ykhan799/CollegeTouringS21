var searchData=
[
  ['souvenirname_80',['souvenirName',['../struct_purchase.html#af8683f8983ec3c19d82b534ff8b4824d',1,'Purchase']]]
];
