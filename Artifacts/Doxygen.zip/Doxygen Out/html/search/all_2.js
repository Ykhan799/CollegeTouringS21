var searchData=
[
  ['databaseviewform_9',['databaseViewForm',['../classdatabase_view_form.html',1,'']]],
  ['dbmanager_10',['DbManager',['../class_db_manager.html',1,'DbManager'],['../class_db_manager.html#a449b4cc451c4ec493345d799891e7eaa',1,'DbManager::DbManager()']]],
  ['displaypurchases_11',['displaypurchases',['../classdisplaypurchases.html',1,'']]],
  ['displaypurchases_2eh_12',['displaypurchases.h',['../displaypurchases_8h.html',1,'']]]
];
