var searchData=
[
  ['databaseviewform_45',['databaseViewForm',['../classdatabase_view_form.html',1,'']]],
  ['dbmanager_46',['DbManager',['../class_db_manager.html',1,'']]],
  ['displaypurchases_47',['displaypurchases',['../classdisplaypurchases.html',1,'']]]
];
