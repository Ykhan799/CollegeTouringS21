var searchData=
[
  ['logindialog_48',['loginDialog',['../classlogin_dialog.html',1,'']]]
];
