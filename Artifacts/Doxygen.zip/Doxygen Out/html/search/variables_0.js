var searchData=
[
  ['campusname_76',['campusName',['../struct_purchase.html#a0908334002aebf103d160a51ff577c9b',1,'Purchase']]]
];
