var searchData=
[
  ['addcampus_58',['addCampus',['../class_db_manager.html#aafbca91557f43c30808c6ac8619b2543',1,'DbManager']]],
  ['addsouvenir_59',['addSouvenir',['../class_db_manager.html#ae61c6c69b6fc0c556c42a6fa694ef576',1,'DbManager']]]
];
