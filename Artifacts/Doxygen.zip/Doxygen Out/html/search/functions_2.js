var searchData=
[
  ['dbmanager_62',['DbManager',['../class_db_manager.html#a449b4cc451c4ec493345d799891e7eaa',1,'DbManager']]]
];
