var searchData=
[
  ['price_78',['price',['../struct_purchase.html#a1af391fd35e41679fbcaac6b5894292a',1,'Purchase']]],
  ['purchases_79',['purchases',['../classpurchasewindow.html#a790cea6a3a227ea2eab7897b0765f327',1,'purchasewindow']]]
];
