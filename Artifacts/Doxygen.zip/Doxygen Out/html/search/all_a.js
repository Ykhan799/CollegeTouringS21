var searchData=
[
  ['totalspent_37',['totalSpent',['../struct_purchase.html#a49a196dfd4409ebbbbc741a79596920d',1,'Purchase']]],
  ['triprouteplanner_38',['tripRoutePlanner',['../classtrip_route_planner.html',1,'']]],
  ['triprouteplanner_2eh_39',['tripRoutePlanner.h',['../trip_route_planner_8h.html',1,'']]],
  ['triptype_40',['TripType',['../trip_route_planner_8h.html#a4370c22283b5c16f23d2a7978303d741',1,'tripRoutePlanner.h']]]
];
