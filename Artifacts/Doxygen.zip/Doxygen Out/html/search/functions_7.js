var searchData=
[
  ['updatesouvenir_75',['updateSouvenir',['../class_db_manager.html#a24145c733af759c3a6b0f67c39217c3b',1,'DbManager']]]
];
