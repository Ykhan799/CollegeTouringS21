var searchData=
[
  ['totalspent_81',['totalSpent',['../struct_purchase.html#a49a196dfd4409ebbbbc741a79596920d',1,'Purchase']]]
];
