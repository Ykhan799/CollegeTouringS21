var searchData=
[
  ['saddleback_34',['SADDLEBACK',['../trip_route_planner_8h.html#a4370c22283b5c16f23d2a7978303d741a20808c7d13e4855b38f876b0d045ca99',1,'tripRoutePlanner.h']]],
  ['souvenirname_35',['souvenirName',['../struct_purchase.html#af8683f8983ec3c19d82b534ff8b4824d',1,'Purchase']]],
  ['souvexists_36',['souvExists',['../class_db_manager.html#ac853b2f31dfb1bc9e96a404ee53566d6',1,'DbManager']]]
];
