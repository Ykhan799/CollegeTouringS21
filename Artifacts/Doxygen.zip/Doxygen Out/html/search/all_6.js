var searchData=
[
  ['numberinputdialog_25',['numberInputDialog',['../classnumber_input_dialog.html',1,'']]],
  ['numberpurchased_26',['numberPurchased',['../struct_purchase.html#ac02aa8310379912b8466f23506aae403',1,'Purchase']]]
];
