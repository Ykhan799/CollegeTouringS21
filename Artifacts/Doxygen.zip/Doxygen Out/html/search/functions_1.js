var searchData=
[
  ['campusexists_60',['campusExists',['../class_db_manager.html#a04a0c4cc23b2fe9acbf393b3f1ae5ec4',1,'DbManager::campusExists(QString &amp;campus)'],['../class_db_manager.html#a44f70b42cc878c465229df2417f046d8',1,'DbManager::campusExists(QString &amp;startCampus, QString &amp;endCampus, double &amp;distance)']]],
  ['createroute_61',['createRoute',['../classtrip_route_planner.html#a46f2131ae753221c57eb83e89dd50f38',1,'tripRoutePlanner']]]
];
