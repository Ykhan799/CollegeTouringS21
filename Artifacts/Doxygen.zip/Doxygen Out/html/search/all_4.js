var searchData=
[
  ['logindialog_22',['loginDialog',['../classlogin_dialog.html',1,'']]]
];
