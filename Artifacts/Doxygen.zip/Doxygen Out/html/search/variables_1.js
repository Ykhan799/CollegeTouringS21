var searchData=
[
  ['numberpurchased_77',['numberPurchased',['../struct_purchase.html#ac02aa8310379912b8466f23506aae403',1,'Purchase']]]
];
