var searchData=
[
  ['populatetransactiontable_27',['populateTransactionTable',['../classdisplaypurchases.html#a2ff56c599818f5443b7d4457243b8b3e',1,'displaypurchases']]],
  ['price_28',['price',['../struct_purchase.html#a1af391fd35e41679fbcaac6b5894292a',1,'Purchase']]],
  ['purchase_29',['Purchase',['../struct_purchase.html',1,'']]],
  ['purchases_30',['purchases',['../classpurchasewindow.html#a790cea6a3a227ea2eab7897b0765f327',1,'purchasewindow']]],
  ['purchasewindow_31',['purchasewindow',['../classpurchasewindow.html',1,'']]],
  ['purchasewindow_2eh_32',['purchasewindow.h',['../purchasewindow_8h.html',1,'']]]
];
