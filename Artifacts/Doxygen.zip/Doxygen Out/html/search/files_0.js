var searchData=
[
  ['displaypurchases_2eh_55',['displaypurchases.h',['../displaypurchases_8h.html',1,'']]]
];
